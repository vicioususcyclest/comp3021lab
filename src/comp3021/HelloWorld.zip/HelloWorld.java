package comp3021;


public interface Shape {	
	public abstract double getArea();
	
	public static double averageArea(Shape[] list) {

	}
}
	public class Trapezoid implements Shape{
		public Trapezoid(double a,double b,double c){
			getArea(a,b,c);
		}
		public double getArea(double a,double b,double c) {
			return (a+b)*c/2;
		}
	}
	
public static void main(String[] args){
		Trapezoid trapezoid = new Trapezoid(1.0, 2.0, 3.0);
		
		Trapezoid t1 = new Trapezoid(2.0, 4.0, 3.0);
		Trapezoid t2 = new Trapezoid(3.0, 4.0, 3.0);
		Trapezoid t3 = new Trapezoid(3.0, 2.5, 1.0);
		
		if (trapezoid.getArea() == 4.5 &&
			averageArea(new Shape[] {t1, t2, t3}) == 7.416666666666667) {
			System.out.println("passed");
		} else {
			System.out.println("failed");
		}

	}
}

